# [HackerResume](https://hackerresume.com)

### Setup
To compile this tex, Please ensure that you have LaTeX installed on your machine, in order to generate the resumes. [Head over here](https://www.latex-project.org/get/) to download it.
  
Alternatively, if you'd like you can use a site like [OverLeaf](https://overleaf.com) to build and edit your LaTeX instead.

## Usage
To generate a PDF from this LaTeX code, navigate to this folder in a terminal and run:

    xelatex resume.tex

### And remember...

>“Everyone appreciates a well-designed resume. Its design, however, should not determine whether or not you are hired.”  

> ~ Harishankaran K. ,   CTO & Co-Founder, HackerRank

You are awesome 🙂, We're super happy to see you're putting so much effort into uplifting yourself by improving your profile. We wish you all the best for your journey ✨🚀

##### Keep Hacking 🎉

#### Made with ♥ by HackerRank Interns